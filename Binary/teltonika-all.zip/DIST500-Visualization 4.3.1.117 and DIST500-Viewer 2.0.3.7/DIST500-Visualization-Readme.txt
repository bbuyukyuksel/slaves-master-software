DIST500-Visualization 4.3.1.117

  DIST500-Visualization.exe
  DIST500-Visualization.exe [-com#] [-sendaddr=#] [-ipaddr=#.#.#.#] [-fa#] [-fa#] [-drv=#] [-filterOff]

  -com#             Load serial port
        #           Port number, e.g. -com1
                    Loads driver for serial port.

  -sendaddr=#       Sender's UIP address
        #           UIP adress from 240 through 254 e.g. -sendaddr=250
                    Assigns tool's UIP address. Default is 252.

  -ipaddr=#.#.#.#   States IP address of the PC.
        #.#.#.#     IP address, e.g. -ipaddr=172.30.31.10
                    Binds tool to an IP address of the PC where communication shall happen. 
                    Setting can be necessary when more than one network interface is present.

  -fa#              States function area number for automatic sensor selection
                    Sensors with this configured FA will be automatically displayed
        #           function area, e.g. -fa1 -fa2 (up to 10 different FAs)

  -drv=#            Driver to use for function area selection
        #           May be e.g. -drv=uip
                                -drv=icef

  -filterOff        Deactivate median noise reduction filter